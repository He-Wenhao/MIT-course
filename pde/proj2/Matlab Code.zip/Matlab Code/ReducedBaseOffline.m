% -------------------------------------------------------------------------
%
%   ReducedBasisOffline.m
%
% -------------------------------------------------------------------------
%   Reduced basis off-line: computes the reduced basis matrices and source 
%   vector from a sample.
% -------------------------------------------------------------------------


% Load grid triangulations
load grids;

% Mesh level to be used
mesh = coarse;

% Load sample matrix and get the number of samples
load sn.dat;
... 

% Solve the sample cases and construct Z
Z = zeros(mesh.nodes,N);
....

% Initialization of reduced-base matrix and vector
ANq = cell(6,1);
FN = zeros(N,1);

% Calculate Anq and FN
....

% Save the reduced matrix and vector
save ReducedBasis.mat ANq FN